package com.example.aimtrainer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;
import java.util.Locale;

public class MainActivity extends Activity {
    AimView aimView;
    TextView angleText, powerText;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(9,9,9));
        TextView title = new TextView(this); title.setText("AIM TRAINER"); title.setTextColor(Color.WHITE); title.setTextSize(22); title.setGravity(Gravity.CENTER); title.setPadding(0,28,0,18);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        aimView = new AimView(this); root.addView(aimView, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(24,12,24,18);
        angleText = label("Angle: 35°"); powerText = label("Power: 70%"); panel.addView(angleText); panel.addView(slider(0,180,35,true)); panel.addView(powerText); panel.addView(slider(0,100,70,false));
        Button reset = new Button(this); reset.setText("RESET AIM"); reset.setOnClickListener(v->{ aimView.angle=35; aimView.power=70; angleText.setText("Angle: 35°"); powerText.setText("Power: 70%"); aimView.invalidate(); }); panel.addView(reset);
        root.addView(panel, new LinearLayout.LayoutParams(-1,-2)); setContentView(root);
    }
    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.LTGRAY); t.setTextSize(15); return t; }
    SeekBar slider(int min,int max,int value,boolean angle){ SeekBar s=new SeekBar(this); s.setMax(max-min); s.setProgress(value-min); s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){ if(angle){aimView.angle=p+min; angleText.setText("Angle: "+aimView.angle+"°");}else{aimView.power=p+min; powerText.setText("Power: "+aimView.power+"%");} aimView.invalidate();} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){} }); return s; }

    static class AimView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float angle=35, power=70;
        AimView(Context c){super(c); p.setStrokeCap(Paint.Cap.ROUND); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); c.drawColor(Color.rgb(18,18,18));
            float l=28,t=28,r=w-28,bot=h-28; p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(94,56,31)); c.drawRoundRect(l,t,r,bot,22,22,p);
            p.setColor(Color.rgb(20,105,73)); c.drawRoundRect(l+24,t+24,r-24,bot-24,14,14,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(215,190,120)); c.drawRoundRect(l+24,t+24,r-24,bot-24,14,14,p);
            float cx=w/2, cy=bot-95; float radius=18; p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); c.drawCircle(cx,cy,radius,p);
            double a=Math.toRadians(angle); float len=120+(power/100f)*(Math.min(w,h)*.38f); float ex=cx+(float)Math.cos(a)*len, ey=cy-(float)Math.sin(a)*len;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.CYAN); c.drawLine(cx,cy,ex,ey,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(225,45,45)); c.drawCircle(ex,ey,14,p);
            p.setColor(Color.argb(120,255,255,255)); p.setTextSize(14); c.drawText("Practice mode — no game automation", l+14, bot-12, p);
        }
    }
}
