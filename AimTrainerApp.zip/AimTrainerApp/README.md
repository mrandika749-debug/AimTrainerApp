# Aim Trainer Android App

This is an independently implemented Android practice app inspired by the workflow of an aim-assistance interface. It does not modify, inject into, or automate another game.

## Build
Use Android Studio with Android SDK 35, or push this folder to GitHub and run the included **Build APK** GitHub Actions workflow. The generated APK is `app/build/outputs/apk/debug/app-debug.apk`.
